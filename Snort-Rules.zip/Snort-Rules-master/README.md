# Snort Rules #

### Description ###
A nice nollection of Snort 2 and 3 Rules. Includes community edition and snapshot clone of another Github repository.

### Snort 2 ###
This repository is archived in snortrules-snapshot-2972.zip for ease of use.

Also there is the public edition snort2-community-rules.tar.

### Snort 3 ###
Public edition of community rules snort3-community-rules.tar.
