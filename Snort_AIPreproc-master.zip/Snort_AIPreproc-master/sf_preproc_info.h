#ifndef 	SF_PREPROC_INFO_H_
#define 	SF_PREPROC_INFO_H_

#define 	MAJOR_VERSION 			0
#define 	MINOR_VERSION 			1
#define 	BUILD_VERSION 			0
#define 	PREPROC_NAME 			"SF_AI"

#define 	DYNAMIC_PREPROC_SETUP 	AI_setup
extern void AI_setup();

#endif /* SF_PREPROC_INFO_H_ */

